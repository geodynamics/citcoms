"""
Collection of CitcomS plugins for Mayavi2
"""
