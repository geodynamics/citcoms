
# This module is initialized by merlin/__init__.py in order to avoid
# the pkg_resources/merlin import cycle.
import merlin
